package CapaLogicaNegocio.Logica_Negocio;

/**
 * Representa una cliente dentro del sistema.
 * Esta entidad almacena y envia la informacion necesaria donde sea solicitada
 *
 * @author Manuel Figueroa (Physanto)
 * @author Santiago Lopez
 */
public class Cliente {

    private String id, nombre, apellido, direccion, cedula, urlImg;

    public Cliente(){}

	public Cliente(String id, String nombre, String apellido, String cedula, String direccion) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
        this.direccion = direccion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
